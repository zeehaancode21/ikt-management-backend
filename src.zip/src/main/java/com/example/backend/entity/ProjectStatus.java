package com.example.backend.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "project_status")
@Data
@AllArgsConstructor
@NoArgsConstructor
// @EntityListeners(AuditingEntityListener.class)
public class ProjectStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String client;

    @Column(name = "project_name", nullable = false)
    private String projectName;

    @Column(name = "job_number", nullable = true, updatable = true)
    private String jobNumber;

    @Column(name = "project_manager")
    private String projectManager;

    @Column(name = "approval_status")
    private String approvalStatus;

    @Column(name = "fab_status")
    private String fabStatus;

    @Column(name = "rfi_recipient_email")
    private String rfiRecipientEmail;

    /**
     * Comma-separated CC addresses from the most recently SENT RFI on this
     * project (written back the same way/place as rfiRecipientEmail — see
     * RfiServiceImpl#createAndSendRfi). Lets the Create RFI form default
     * its CC field to "whatever I CC'd last time" the same way the To
     * field already defaults from rfiRecipientEmail, instead of starting
     * empty every time.
     */
    @Column(name = "rfi_cc_emails", columnDefinition = "TEXT")
    private String rfiCcEmails;

    @Column(columnDefinition = "TEXT")
    private String remarks;

    private String team;

    @Column(name = "ifc_date")
    private String ifcDate;

    @Column(name = "ifa_date")
    private String ifaDate;

    @Column(nullable = false)
    private String year;

    @Column(name = "created_at")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime updatedAt;

}